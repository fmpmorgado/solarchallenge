class SolarInverter():
    pass